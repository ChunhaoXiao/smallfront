var thisData = [
  {
    "datasid": 0,
    "image": "/images/latest_list_43.jpg",
    "tatle": "牛九州海鲜全家福",
    "number": "44",
    "money": "99"
  },
  {
    "datasid": 1,
    "image": "/images/latest_list_43.jpg",
    "tatle": "牛九州海鲜全家福",
    "number": "44",
    "money": "99"
  },
  {
    "datasid": 2,
    "image": "/images/latest_list_43.jpg",
    "tatle": "牛九州海鲜全家福",
    "number": "44",
    "money": "99"
  },
  {
    "datasid": 3,
    "image": "/images/latest_list_43.jpg",
    "tatle": "牛九州海鲜全家福",
    "number": "44",
    "money": "99"
  },
  {
    "datasid": 4,
    "image": "/images/latest_list_43.jpg",
    "tatle": "牛九州海鲜全家福",
    "number": "44",
    "money": "99"
  },
  {
    "datasid": 5,
    "image": "/images/latest_list_43.jpg",
    "tatle": "牛九州海鲜全家福",
    "number": "44",
    "money": "99"
  }
]

module.exports = {
  thisData: thisData
}