//index.js
//获取应用实例

const app = getApp();
var newsData = require("../data_index/data_index.js")

Page({

  /**
   * 页面的初始数据
   */
  data: {
    uesData:""
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      useData:newsData.thisData
    })
    var list=this.data.useData.length;
    for(let i = 0; i < list; i++){
      var tatleA = this.data.uesData[i].tatle;
      var moneyB = this.data.useData[i].money;
      var tatleL = tatleA.length;
      var moneyL = moneyB.length;
      var tatleS = tatleA.substring(0, 10);
      var moneyS = moneyB.substring(0, 4);

      var index = 'useData['+ i +'],tatle'
      var lndex = 'useData['+ i +'],money'
      this.setData({
        [index]: tatleS,
        [lndex]: moneyS
      })
    }
  },

  telclick: function () {
    wx.makePhoneCall({
      phoneNumber: '13555934217'
    })
  }, 

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  intoSearchFunc:function (e) {
    wx.navigateTo({
      url: '../components/search/search'
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.checklogin();
    var that = this
    var openid = wx.getStorageSync('openid');
    console.log(openid);
 
  },


})